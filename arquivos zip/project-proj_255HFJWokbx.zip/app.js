class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Algo deu errado</h1>
            <p className="text-gray-600 mb-4">Desculpe, ocorreu um erro inesperado.</p>
            <button
              onClick={() => window.location.reload()}
              className="px-6 py-2 bg-[var(--primary-color)] text-white rounded-lg hover:opacity-90"
            >
              Recarregar Página
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

function App() {
  try {
    const [timeRange, setTimeRange] = React.useState('30d');
    const [metrics, setMetrics] = React.useState(mockMetrics);
    const [alerts, setAlerts] = React.useState(mockAlerts);

    return (
      <div className="min-h-screen" data-name="app" data-file="app.js">
        <Header timeRange={timeRange} onTimeRangeChange={setTimeRange} />
        
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <MetricCard
              title="Vendas Mensais"
              value={metrics.monthlySales.value}
              change={metrics.monthlySales.change}
              icon="trending-up"
              format="currency"
            />
            <MetricCard
              title="Taxa de Conversão"
              value={metrics.conversionRate.value}
              change={metrics.conversionRate.change}
              icon="target"
              format="percentage"
            />
            <MetricCard
              title="CAC"
              value={metrics.cac.value}
              change={metrics.cac.change}
              icon="dollar-sign"
              format="currency"
              invertChange={true}
            />
            <MetricCard
              title="Receita Recorrente"
              value={metrics.mrr.value}
              change={metrics.mrr.change}
              icon="repeat"
              format="currency"
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <SalesChart data={mockSalesData} />
            <ConversionChart data={mockConversionData} />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {alerts.map((alert, index) => (
              <AlertCard key={index} alert={alert} />
            ))}
          </div>
        </main>
      </div>
    );
  } catch (error) {
    console.error('App component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>
);