function AlertCard({ alert }) {
  try {
    const getAlertStyle = (type) => {
      switch (type) {
        case 'success':
          return {
            bg: 'bg-green-50',
            border: 'border-green-200',
            icon: 'check-circle',
            iconColor: 'text-green-600'
          };
        case 'warning':
          return {
            bg: 'bg-yellow-50',
            border: 'border-yellow-200',
            icon: 'alert-triangle',
            iconColor: 'text-yellow-600'
          };
        case 'danger':
          return {
            bg: 'bg-red-50',
            border: 'border-red-200',
            icon: 'alert-circle',
            iconColor: 'text-red-600'
          };
        default:
          return {
            bg: 'bg-blue-50',
            border: 'border-blue-200',
            icon: 'info',
            iconColor: 'text-blue-600'
          };
      }
    };

    const style = getAlertStyle(alert.type);

    return (
      <div className={`${style.bg} border ${style.border} rounded-lg p-4`} data-name="alert-card" data-file="components/AlertCard.js">
        <div className="flex items-start">
          <div className={`icon-${style.icon} text-xl ${style.iconColor} mr-3 mt-0.5`}></div>
          <div className="flex-1">
            <h4 className="font-semibold text-[var(--text-primary)] mb-1">{alert.title}</h4>
            <p className="text-sm text-[var(--text-secondary)]">{alert.message}</p>
            <p className="text-xs text-[var(--text-secondary)] mt-2">{alert.timestamp}</p>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('AlertCard component error:', error);
    return null;
  }
}