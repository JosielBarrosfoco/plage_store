function ConversionChart({ data }) {
  try {
    const chartRef = React.useRef(null);
    const chartInstance = React.useRef(null);

    React.useEffect(() => {
      if (chartRef.current) {
        const ctx = chartRef.current.getContext('2d');
        
        if (chartInstance.current) {
          chartInstance.current.destroy();
        }

        chartInstance.current = new ChartJS(ctx, {
          type: 'bar',
          data: {
            labels: data.labels,
            datasets: [{
              label: 'Taxa (%)',
              data: data.values,
              backgroundColor: [
                'rgba(59, 130, 246, 0.8)',
                'rgba(16, 185, 129, 0.8)',
                'rgba(245, 158, 11, 0.8)',
                'rgba(139, 92, 246, 0.8)'
              ],
              borderRadius: 6
            }]
          },
          options: getChartOptions('Funil de Conversão', false)
        });
      }

      return () => {
        if (chartInstance.current) {
          chartInstance.current.destroy();
        }
      };
    }, [data]);

    return (
      <div className="card" data-name="conversion-chart" data-file="components/ConversionChart.js">
        <h3 className="text-lg font-semibold text-[var(--text-primary)] mb-4">Funil de Conversão</h3>
        <canvas ref={chartRef}></canvas>
      </div>
    );
  } catch (error) {
    console.error('ConversionChart component error:', error);
    return null;
  }
}