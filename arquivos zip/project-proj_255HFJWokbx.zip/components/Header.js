function Header({ timeRange, onTimeRangeChange }) {
  try {
    return (
      <header className="bg-white border-b border-[var(--border-color)]" data-name="header" data-file="components/Header.js">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div>
              <h1 className="text-3xl font-bold text-[var(--text-primary)]">Dashboard de Vendas</h1>
              <p className="mt-1 text-sm text-[var(--text-secondary)]">Acompanhe suas métricas em tempo real</p>
            </div>
            
            <div className="mt-4 md:mt-0 flex items-center space-x-2">
              <span className="text-sm text-[var(--text-secondary)]">Período:</span>
              <select
                value={timeRange}
                onChange={(e) => onTimeRangeChange(e.target.value)}
                className="px-4 py-2 border border-[var(--border-color)] rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[var(--primary-color)]"
              >
                <option value="7d">Últimos 7 dias</option>
                <option value="30d">Últimos 30 dias</option>
                <option value="90d">Últimos 90 dias</option>
                <option value="1y">Último ano</option>
              </select>
            </div>
          </div>
        </div>
      </header>
    );
  } catch (error) {
    console.error('Header component error:', error);
    return null;
  }
}