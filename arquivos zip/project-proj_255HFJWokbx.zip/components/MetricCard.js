function MetricCard({ title, value, change, icon, format = 'number', invertChange = false }) {
  try {
    const formatValue = (val) => {
      if (format === 'currency') {
        return `R$ ${val.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`;
      } else if (format === 'percentage') {
        return `${val}%`;
      }
      return val.toLocaleString('pt-BR');
    };

    const isPositive = invertChange ? change < 0 : change > 0;
    const changeColor = isPositive ? 'text-[var(--success-color)]' : 'text-[var(--danger-color)]';
    const changeIcon = isPositive ? 'trending-up' : 'trending-down';

    return (
      <div className="card" data-name="metric-card" data-file="components/MetricCard.js">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <p className="text-sm font-medium text-[var(--text-secondary)]">{title}</p>
            <p className="mt-2 text-3xl font-bold text-[var(--text-primary)]">{formatValue(value)}</p>
            <div className={`mt-2 flex items-center text-sm ${changeColor}`}>
              <div className={`icon-${changeIcon} text-base mr-1`}></div>
              <span className="font-medium">{Math.abs(change)}%</span>
              <span className="ml-1 text-[var(--text-secondary)]">vs período anterior</span>
            </div>
          </div>
          <div className="w-12 h-12 rounded-lg flex items-center justify-center bg-[var(--secondary-color)]">
            <div className={`icon-${icon} text-xl text-[var(--primary-color)]`}></div>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('MetricCard component error:', error);
    return null;
  }
}