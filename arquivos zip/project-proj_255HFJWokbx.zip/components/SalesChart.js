function SalesChart({ data }) {
  try {
    const chartRef = React.useRef(null);
    const chartInstance = React.useRef(null);

    React.useEffect(() => {
      if (chartRef.current) {
        const ctx = chartRef.current.getContext('2d');
        
        if (chartInstance.current) {
          chartInstance.current.destroy();
        }

        chartInstance.current = new ChartJS(ctx, {
          type: 'line',
          data: {
            labels: data.labels,
            datasets: [{
              label: 'Vendas (R$)',
              data: data.values,
              borderColor: getComputedStyle(document.documentElement).getPropertyValue('--primary-color').trim(),
              backgroundColor: getComputedStyle(document.documentElement).getPropertyValue('--secondary-color').trim(),
              tension: 0.4,
              fill: true
            }]
          },
          options: getChartOptions('Vendas Mensais', true)
        });
      }

      return () => {
        if (chartInstance.current) {
          chartInstance.current.destroy();
        }
      };
    }, [data]);

    return (
      <div className="card" data-name="sales-chart" data-file="components/SalesChart.js">
        <h3 className="text-lg font-semibold text-[var(--text-primary)] mb-4">Evolução de Vendas</h3>
        <canvas ref={chartRef}></canvas>
      </div>
    );
  } catch (error) {
    console.error('SalesChart component error:', error);
    return null;
  }
}