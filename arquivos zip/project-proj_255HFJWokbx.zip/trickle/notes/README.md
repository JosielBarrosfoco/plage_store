# Dashboard de Vendas

Dashboard interativo para acompanhamento de métricas de vendas e performance comercial.

## Funcionalidades

- **Métricas Principais**: Vendas mensais, taxa de conversão, CAC e MRR
- **Gráficos Interativos**: Visualização de evolução de vendas e funil de conversão
- **Alertas Automáticos**: Notificações sobre performance e metas
- **Filtros de Período**: Análise por diferentes intervalos de tempo

## Estrutura do Projeto

- `index.html` - Página principal com configurações e estilos
- `app.js` - Componente principal da aplicação
- `components/` - Componentes React reutilizáveis
- `utils/` - Funções utilitárias e dados de exemplo

## Tecnologias

- React 18
- Chart.js para gráficos
- TailwindCSS para estilização
- Lucide Icons

## Métricas Monitoradas

1. **Vendas Mensais**: Receita total do período
2. **Taxa de Conversão**: Percentual de visitantes que se tornam clientes
3. **CAC**: Custo de Aquisição de Cliente
4. **MRR**: Receita Recorrente Mensal

---

*Última atualização: 26/11/2025*