When updating the project

- Always check if the README.md in trickle/notes needs to be updated
- Update README.md when:
  - New features are added
  - Project structure changes significantly
  - New technologies or libraries are integrated
  - Important functionality is modified or removed
- Keep README.md concise and informative
- Include the current date in the last update section