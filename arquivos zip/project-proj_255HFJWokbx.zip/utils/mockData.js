const mockMetrics = {
  monthlySales: {
    value: 487650,
    change: 12.5
  },
  conversionRate: {
    value: 3.8,
    change: 0.5
  },
  cac: {
    value: 145.50,
    change: -8.2
  },
  mrr: {
    value: 125890,
    change: 15.3
  }
};

const mockSalesData = {
  labels: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'],
  values: [385000, 412000, 395000, 428000, 445000, 461000, 439000, 475000, 492000, 510000, 487000, 528000]
};

const mockConversionData = {
  labels: ['Visitantes', 'Leads', 'Oportunidades', 'Clientes'],
  values: [100, 35, 18, 3.8]
};

const mockAlerts = [
  {
    type: 'success',
    title: 'Meta de Vendas Atingida',
    message: 'Parabéns! A meta mensal de R$ 450.000 foi superada em 8.4%.',
    timestamp: 'Há 2 horas'
  },
  {
    type: 'warning',
    title: 'Taxa de Conversão em Queda',
    message: 'A taxa de conversão caiu 0.3% nos últimos 7 dias. Recomendamos análise do funil.',
    timestamp: 'Há 5 horas'
  },
  {
    type: 'info',
    title: 'Novo Relatório Disponível',
    message: 'O relatório de análise de CAC por canal está pronto para visualização.',
    timestamp: 'Há 1 dia'
  },
  {
    type: 'success',
    title: 'MRR em Crescimento',
    message: 'A receita recorrente mensal cresceu 15.3% comparado ao mês anterior.',
    timestamp: 'Há 2 dias'
  }
];